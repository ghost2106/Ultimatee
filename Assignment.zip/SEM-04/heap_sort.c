#include <stdio.h>


void heapify(int arr[], int n, int i) {
    int largest = i;
    int leftchild = 2*i + 1;
    int rightchild = 2*i + 2;
    int temp;

 
    if (leftchild < n && arr[leftchild] > arr[largest])
        largest = leftchild;


    if (rightchild < n && arr[rightchild] > arr[largest])
        largest = rightchild;


    if (largest != i) {
        temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;
        
        heapify(arr, n, largest);
    }
}

void heapSort(int arr[], int n) {
    int i, temp;


    for (i = n/2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    for (i = n-1; i > 0; i--) {
        temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;

        heapify(arr, i, 0);
    }
}


void printArray(int arr[], int n) {
    int i;
    for (i = 0; i < n; i++)
        printf("%d ", arr[i]);
}

int main() {
    int n, i;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr[n];  

    printf("Enter %d elements:\n", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    heapSort(arr, n);

    printf("Sorted array: ");
    printArray(arr, n);

    return 0;
}