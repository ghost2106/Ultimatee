#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *left, *right;
    int lbit, rbit;  // 0 = real child, 1 = thread
};

// Create a new node
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    newNode->lbit = 1;  // Initially thread
    newNode->rbit = 1;  // Initially thread
    return newNode;
}

// Insert a value into threaded BST
struct Node* insert(struct Node* root, int data) {
    struct Node *ptr = root;
    struct Node *par = NULL;

    // Find the insertion position
    while (ptr != NULL) {
        if (data == ptr->data) {
            printf("Duplicate key: %d\n", data);
            return root;
        }
        par = ptr;

        if (data < ptr->data) {
            if (ptr->lbit == 0)  // Real left child exists
                ptr = ptr->left;
            else
                break;  // Left is thread, found insertion point
        } else {
            if (ptr->rbit == 0)  // Real right child exists
                ptr = ptr->right;
            else
                break;  // Right is thread, found insertion point
        }
    }

    struct Node* newNode = createNode(data);

    if (par == NULL) {
        // First node (root)
        root = newNode;
        newNode->left = NULL;
        newNode->right = NULL;
    } else if (data < par->data) {
        // Insert as left child
        newNode->left = par->left;     // Inherit predecessor
        newNode->right = par;          // Thread to parent
        par->lbit = 0;                 // Mark as real child
        par->left = newNode;
    } else {
        // Insert as right child
        newNode->left = par;           // Thread to parent
        newNode->right = par->right;   // Inherit successor
        par->rbit = 0;                 // Mark as real child
        par->right = newNode;
    }

    return root;
}

// Find leftmost node (smallest)
struct Node* findLeftmost(struct Node* node) {
    if (node == NULL)
        return NULL;

    while (node->lbit == 0)  // While real left child exists
        node = node->left;

    return node;
}

// Find rightmost node (largest)
struct Node* findRightmost(struct Node* node) {
    if (node == NULL)
        return NULL;

    while (node->rbit == 0)  // While real right child exists
        node = node->right;

    return node;
}

// Inorder Traversal (Left -> Root -> Right)
void inorder(struct Node* root) {
    if (root == NULL) {
        printf("Tree is empty!\n");
        return;
    }

    struct Node* cur = findLeftmost(root);

    while (cur != NULL) {
        printf("%d ", cur->data);

        if (cur->rbit == 1) {
            // Right is thread, follow it to successor
            cur = cur->right;
        } else {
            // Right is real child, go to leftmost in right subtree
            cur = findLeftmost(cur->right);
        }
    }
    printf("\n");
}

// Reverse Inorder Traversal (Right -> Root -> Left)
void reverseInorder(struct Node* root) {
    if (root == NULL) {
        printf("Tree is empty!\n");
        return;
    }

    struct Node* cur = findRightmost(root);

    while (cur != NULL) {
        printf("%d ", cur->data);

        if (cur->lbit == 1) {
            // Left is thread, follow it to predecessor
            cur = cur->left;
        } else {
            // Left is real child, go to rightmost in left subtree
            cur = findRightmost(cur->left);
        }
    }
    printf("\n");
}

// Search for a value
struct Node* search(struct Node* root, int data) {
    struct Node* cur = findLeftmost(root);

    while (cur != NULL) {
        if (cur->data == data)
            return cur;  // Found
        else if (data > cur->data) {
            if (cur->rbit == 1)
                cur = cur->right;
            else
                cur = findLeftmost(cur->right);
        } else {
            break;  // Not found
        }
    }
    return NULL;
}

// Display tree structure (preorder style for visualization)
void displayTree(struct Node* root, int level) {
    if (root == NULL)
        return;

    displayTree(root->right, level + 1);

    for (int i = 0; i < level; i++)
        printf("    ");

    printf("%d\n", root->data);

    displayTree(root->left, level + 1);
}

// Main function
int main() {
    struct Node* root = NULL;

    printf("===== Threaded Binary Search Tree =====\n\n");

    // Insert values
    printf("Inserting: 50, 30, 70, 20, 40, 60, 80, 10, 25, 35, 65\n\n");
    root = insert(root, 50);
    root = insert(root, 30);
    root = insert(root, 70);
    root = insert(root, 20);
    root = insert(root, 40);
    root = insert(root, 60);
    root = insert(root, 80);
    root = insert(root, 10);
    root = insert(root, 25);
    root = insert(root, 35);
    root = insert(root, 65);

    // Display tree structure
    printf("Tree Structure:\n");
    displayTree(root, 0);
    printf("\n");

    // Inorder traversal
    printf("Inorder Traversal (Left->Root->Right): ");
    inorder(root);

    // Reverse inorder traversal
    printf("Reverse Inorder (Right->Root->Left): ");
    reverseInorder(root);

    // Search examples
    printf("\nSearch Operations:\n");
    int searchValues[] = {35, 15, 80, 5};
    for (int i = 0; i < 4; i++) {
        struct Node* result = search(root, searchValues[i]);
        if (result != NULL)
            printf("  %d found in tree\n", searchValues[i]);
        else
            printf("  %d NOT found in tree\n", searchValues[i]);
    }

    printf("\nSmallest: %d\n", findLeftmost(root)->data);
    printf("Largest: %d\n", findRightmost(root)->data);

    return 0;
}
