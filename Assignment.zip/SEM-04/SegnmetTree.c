
#include <stdio.h>

int tree[1000];
int arr[1000];

void buildTree(int node, int start, int end) {
    if (start == end) {
        tree[node] = arr[start];
    } else {
        int mid = (start + end) / 2;

        buildTree(2 * node, start, mid);
        buildTree(2 * node + 1, mid + 1, end);

        tree[node] = tree[2 * node] + tree[2 * node + 1];
    }
}

void updateTree(int node, int start, int end, int idx, int value) {
    if (start == end) {
        arr[idx] = value;
        tree[node] = value;
    } else {
        int mid = (start + end) / 2;

        if (idx <= mid)
            updateTree(2 * node, start, mid, idx, value);
        else
            updateTree(2 * node + 1, mid + 1, end, idx, value);

        tree[node] = tree[2 * node] + tree[2 * node + 1];
    }
}

int rangeQuery(int node, int start, int end, int l, int r) {
    if (r < start || end < l)
        return 0;

    if (l <= start && end <= r)
        return tree[node];

    int mid = (start + end) / 2;

    int p1 = rangeQuery(2 * node, start, mid, l, r);
    int p2 = rangeQuery(2 * node + 1, mid + 1, end, l, r);

    return p1 + p2;
}

void printTree(int size) {
    printf("Segment Tree Elements:\n");

    for (int i = 1; i < 2 * size; i++) {
        printf("%d ", tree[i]);
    }

    printf("\n");
}

int main() {
    int n;

    printf("Enter size of array: ");
    scanf("%d", &n);

    printf("Enter array elements:\n");

    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    buildTree(1, 0, n - 1);

    printTree(n);

    int idx, value;

    printf("Enter index to update: ");
    scanf("%d", &idx);

    printf("Enter new value: ");
    scanf("%d", &value);

    updateTree(1, 0, n - 1, idx, value);

    printTree(n);

    int l, r;

    printf("Enter range for query (l r): ");
    scanf("%d %d", &l, &r);

    int sum = rangeQuery(1, 0, n - 1, l, r);

    printf("Sum in range [%d, %d] = %d\n", l, r, sum);

    return 0;
}
