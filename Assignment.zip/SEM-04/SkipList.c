#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_LEVEL 4
#define P 0.5

struct Node {
    int key;
    struct Node *forward[MAX_LEVEL];
};

struct Node* createNode(int key, int level) {
    struct Node* n = (struct Node*)malloc(sizeof(struct Node));
    n->key = key;
    for(int i=0;i<MAX_LEVEL;i++) n->forward[i]=NULL;
    return n;
}

int randomLevel() {
    int level = 1;
    while(((float)rand()/RAND_MAX) < P && level < MAX_LEVEL)
        level++;
    return level;
}

void insert(struct Node *header, int key) {
    struct Node *update[MAX_LEVEL];
    struct Node *curr = header;

    for(int i=MAX_LEVEL-1;i>=0;i--) {
        while(curr->forward[i] != NULL && curr->forward[i]->key < key)
            curr = curr->forward[i];
        update[i] = curr;
    }

    curr = curr->forward[0];

    if(curr == NULL || curr->key != key) {
        int level = randomLevel();
        struct Node *newNode = createNode(key, level);

        for(int i=0;i<level;i++) {
            newNode->forward[i] = update[i]->forward[i];
            update[i]->forward[i] = newNode;
        }
    }
}

int search(struct Node *header, int key) {
    struct Node *curr = header;

    for(int i=MAX_LEVEL-1;i>=0;i--) {
        while(curr->forward[i] && curr->forward[i]->key < key)
            curr = curr->forward[i];
    }

    curr = curr->forward[0];

    if(curr && curr->key == key)
        return 1;
    return 0;
}

void display(struct Node *header) {
    printf("\nSkip List Levels:\n");
    for(int i=MAX_LEVEL-1;i>=0;i--) {
        struct Node *node = header->forward[i];
        printf("Level %d: ", i);
        while(node) {
            printf("%d ", node->key);
            node = node->forward[i];
        }
        printf("\n");
    }
}

int main() {
    srand(time(NULL));

    struct Node *header = createNode(-1, MAX_LEVEL);
    int n, key, s;

    printf("Enter number of elements (>=8): ");
    scanf("%d", &n);

    printf("Enter elements:\n");
    for(int i=0;i<n;i++) {
        scanf("%d", &key);
        insert(header, key);
    }
    display(header);
    printf("\nEnter element to search: ");
    scanf("%d", &s);

    if(search(header, s))
        printf("%d found in Skip List\n", s);
    else
        printf("%d not found in Skip List\n", s);
    return 0;
}