#include <stdio.h>
#include <stdlib.h>

// Structure of a Threaded Binary Tree Node
struct Node {
    int data;
    struct Node *left, *right;
    int lthread, rthread;  // 0 = normal link, 1 = thread link
};

// Function to create a new node
struct Node* createNode(int data) {
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node));

    temp->data = data;

    // Initially both pointers are NULL
    temp->left = temp->right = NULL;

    // Initially no threads are present
    temp->lthread = 0;
    temp->rthread = 0;

    return temp;
}

// Function to insert node in level order (like a complete binary tree)
struct Node* insert(struct Node* root, int data) {

    // If tree is empty, create root node
    if (root == NULL)
        return createNode(data);

    // Queue for level order traversal
    struct Node* queue[100];
    int front = 0, rear = 0;

    // Start from root
    queue[rear++] = root;

    while (front < rear) {

        // Get current node from queue
        struct Node* temp = queue[front++];

        // Insert in left child if empty
        if (temp->left == NULL) {
            temp->left = createNode(data);
            return root;
        } else {
            queue[rear++] = temp->left;
        }

        // Insert in right child if empty
        if (temp->right == NULL) {
            temp->right = createNode(data);
            return root;
        } else {
            queue[rear++] = temp->right;
        }
    }

    return root;
}

// Function to create threads using inorder traversal
void createThreads(struct Node* root, struct Node** prev) {

    if (root == NULL)
        return;

    // Traverse left subtree
    createThreads(root->left, prev);

    // If left child is NULL, create thread to inorder predecessor
    if (root->left == NULL) {
        root->left = *prev;
        root->lthread = 1;   // mark as thread
    }

    // If previous node exists and its right is NULL,
    // create thread to inorder successor
    if (*prev != NULL && (*prev)->right == NULL) {
        (*prev)->right = root;
        (*prev)->rthread = 1;  // mark as thread
    }

    // Update previous node to current node
    *prev = root;

    // Traverse right subtree
    createThreads(root->right, prev);
}

// Function to find leftmost node in tree (starting point of inorder)
struct Node* leftMost(struct Node* root) {

    if (root == NULL)
        return NULL;

    // Go to extreme left (only through real child links, not threads)
    while (root->lthread == 0 && root->left != NULL)
        root = root->left;

    return root;
}

// Inorder traversal using threads (no recursion, no stack)
void inorder(struct Node* root) {

    // Start from leftmost node
    struct Node* curr = leftMost(root);

    while (curr != NULL) {

        // Print current node
        printf("%d ", curr->data);

        // If right pointer is a thread, go to inorder successor
        if (curr->rthread == 1)
            curr = curr->right;

        // Else go to leftmost node in right subtree
        else
            curr = leftMost(curr->right);
    }
}

// Main function
int main() {

    struct Node* root = NULL;
    int n, val;

    // Input number of nodes
    printf("Enter number of nodes: ");
    scanf("%d", &n);

    // Insert nodes into binary tree
    for (int i = 0; i < n; i++) {
        printf("Enter value: ");
        scanf("%d", &val);
        root = insert(root, val);
    }

    // Pointer used for threading (keeps track of previous node in inorder)
    struct Node* prev = NULL;

    // Convert tree into threaded binary tree
    createThreads(root, &prev);

    // Display inorder traversal using threads
    printf("Inorder Traversal using Threads: ");
    inorder(root);

    return 0;
}