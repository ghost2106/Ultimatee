#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALPHABET_SIZE 26

struct TrieNode {
    struct TrieNode *children[ALPHABET_SIZE];
    int isEndOfWord;
};

struct TrieNode* createNode() {
    struct TrieNode *node = (struct TrieNode*)malloc(sizeof(struct TrieNode));
    node->isEndOfWord = 0;
    for(int i=0;i<ALPHABET_SIZE;i++) node->children[i]=NULL;
    return node;
}

void insert(struct TrieNode *root, char *key) {
    struct TrieNode *curr = root;
    for(int i=0; key[i]; i++) {
        int index = key[i] - 'a';
        if(curr->children[index] == NULL)
            curr->children[index] = createNode();
        curr = curr->children[index];
    }
    curr->isEndOfWord = 1;
}

int search(struct TrieNode *root, char *key) {
    struct TrieNode *curr = root;
    for(int i=0; key[i]; i++) {
        int index = key[i] - 'a';
        if(curr->children[index] == NULL)
            return 0;
        curr = curr->children[index];
    }
    return curr->isEndOfWord;
}

int startsWith(struct TrieNode *root, char *prefix) {
    struct TrieNode *curr = root;
    for(int i=0; prefix[i]; i++) {
        int index = prefix[i] - 'a';
        if(curr->children[index] == NULL)
            return 0;
        curr = curr->children[index];
    }
    return 1;
}

int main() {
    struct TrieNode *root = createNode();
    int n, m, p;
    char word[100];

    printf("Enter number of words to insert: ");
    scanf("%d", &n);

    printf("Enter words (lowercase only):\n");
    for(int i=0;i<n;i++) {
        scanf("%s", word);
        insert(root, word);
    }

    printf("\nEnter number of words to search: ");
    scanf("%d", &m);

    printf("Enter words to search:\n");
    for(int i=0;i<m;i++) {
        scanf("%s", word);
        if(search(root, word))
            printf("%s -> Found\n", word);
        else
            printf("%s -> Not Found\n", word);
    }

    printf("\nEnter number of prefixes to check: ");
    scanf("%d", &p);

    printf("Enter prefixes:\n");
    for(int i=0;i<p;i++) {
        scanf("%s", word);
        if(startsWith(root, word))
            printf("%s -> Exists\n", word);
        else
            printf("%s -> Not Exists\n", word);
    }

    return 0;
}

