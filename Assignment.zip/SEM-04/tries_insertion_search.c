#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 26

// Trie Node Structure
struct TrieNode {
    struct TrieNode *children[SIZE];
    int isEnd;   // 1 if word ends here
};

// Function to create new Trie node
struct TrieNode* createNode() {
    struct TrieNode* node =
        (struct TrieNode*)malloc(sizeof(struct TrieNode));

    node->isEnd = 0;

    // Initialize all children as NULL
    for (int i = 0; i < SIZE; i++)
        node->children[i] = NULL;

    return node;
}

// Function to insert word into Trie
void insert(struct TrieNode* root, char word[]) {       //word =abc

    struct TrieNode* curr = root;

    for (int i = 0; word[i] != '\0'; i++) {

        int index = word[i] - 'a';      // index = 0 for 'a', 1 for 'b', 2 for 'c'

        // Create node if not present
        if (curr->children[index] == NULL)      
            curr->children[index] = createNode();       //curr->children[0] = createNode() for 'a', 
                                                        //curr->children[1] = createNode() for 'b', 
                                                        //curr->children[2] = createNode() for 'c'  

        // Move to next node
        curr = curr->children[index];       
    }

    // Mark end of word
    curr->isEnd = 1;

    printf("Word Inserted Successfully\n");
}

// Function to search complete word
int search(struct TrieNode* root, char word[]) {

    struct TrieNode* curr = root;

    for (int i = 0; word[i] != '\0'; i++) {

        int index = word[i] - 'a';

        // If character path not found
        if (curr->children[index] == NULL)
            return 0;

        curr = curr->children[index];
    }

    // Return true only if complete word exists
    return curr->isEnd;
}

// Function to check prefix exists
int checkPrefix(struct TrieNode* root, char prefix[]) {

    struct TrieNode* curr = root;

    for (int i = 0; prefix[i] != '\0'; i++) {

        int index = prefix[i] - 'a';

        // Prefix path not found
        if (curr->children[index] == NULL)
            return 0;

        curr = curr->children[index];
    }

    // Prefix exists
    return 1;
}

// Main Function
int main() {

    struct TrieNode* root = createNode();

    int choice;
    char word[100];

    while (1) {

        printf("\n--- TRIE OPERATIONS ---\n");
        printf("1. Insert Word\n");
        printf("2. Search Word\n");
        printf("3. Check Prefix\n");
        printf("4. Exit\n");

        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {

            case 1:
                printf("Enter word to insert: ");
                scanf("%s", word);

                insert(root, word);
                break;

            case 2:
                printf("Enter word to search: ");
                scanf("%s", word);

                if (search(root, word))
                    printf("Word Found\n");
                else
                    printf("Word Not Found\n");

                break;

            case 3:
                printf("Enter prefix: ");
                scanf("%s", word);

                if (checkPrefix(root, word))
                    printf("Prefix Exists\n");
                else
                    printf("Prefix Does Not Exist\n");

                break;

            case 4:
                printf("Exiting...\n");
                exit(0);

            default:
                printf("Invalid Choice\n");
        }
    }

    return 0;
}