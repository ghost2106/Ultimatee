        #include <stdio.h>
        #include <stdlib.h>

        struct Node {
            int data;
            struct Node *left, *right;
            int lbit, rbit;
        };
        struct Node* createNode(int data) {
            struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
            temp->data = data;
            temp->left = temp->right = NULL;
            temp->lbit = temp->rbit = 1;
            return temp;
        }

        struct Node* insert(struct Node* root, int data) {
            struct Node *ptr = root;
            struct Node *par = NULL;        

            while (ptr != NULL) {
                if (data == ptr->data) {
                    printf("Duplicate key!\n");
                    return root;
                }
                par = ptr;

                // Finding the position to insert the new node
                if (data < ptr->data) {
                    if (ptr->lbit == 0)
                        ptr = ptr->left;
                    else
                        break;
                } else {
                    if (ptr->rbit == 0)
                        ptr = ptr->right;
                    else
                        break;
                }
            }

        struct Node* newNode = createNode(data);        //Creating new node
          
            //  Inserting the new node
            if (par == NULL) {
                root = newNode;
                newNode->left = newNode->right = NULL;
            }
            else if (data < par->data) {
                newNode->left = par->left;  //Assigning previous parent lthread to new node left
                newNode->right = par;
                par->lbit = 0;
                par->left = newNode;
            }
            else {
                newNode->left = par;        // Assigning previous parent rthread to new node left
                newNode->right = par->right;
                par->rbit = 0;
                par->right = newNode;
            }

            return root;
        }
        
        struct Node* leftmost(struct Node* root) {
            if (root == NULL)
                return NULL;

            while (root->lbit == 0)
                root = root->left;

            return root;
        }

        void inorder(struct Node* root) {
            struct Node* cur = leftmost(root);

            while (cur != NULL) {
                printf("%d ", cur->data);

                if (cur->rbit == 1)
                    cur = cur->right;
                else
                    cur = leftmost(cur->right);
            }
        }
        int main() {
            struct Node* root = NULL;

            root = insert(root, 10);
            root = insert(root, 5);
            root = insert(root, 15);
            root = insert(root, 2);
            root = insert(root, 7);

            printf("Inorder Traversal:\n");
            inorder(root);

            return 0;
        }
